# SwiftPOS

This repo hosts a SwiftPOS Next.js 16 App Router-based POS prototype with a JSON-backed store and a future Postgres-backed runtime.
