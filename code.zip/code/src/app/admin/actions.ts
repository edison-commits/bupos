"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { hashSecret } from "@/lib/auth/crypto";
import { canManageEmployeeRole, requireAdminPermission } from "@/lib/authz";
import { signInAdmin, signOutAdmin } from "@/lib/auth/session";
import { mutateStore } from "@/lib/persistence/store";
import type { RoleKey } from "@/lib/domain/types";
import {
  pgCreateCategory,
  pgCreateProduct,
  pgCreateVariant,
  pgCreateInventoryLevel,
  pgAdjustInventory,
  pgCreateEmployee,
  pgToggleEmployee,
  pgReadEmployeeById,
  pgInsertAuditEvent,
} from "@/lib/persistence/postgres-store";

const usePg = () => !!process.env.USE_POSTGRES;

function now() {
  return new Date().toISOString();
}

export async function adminLoginAction(formData: FormData) {
  await signInAdmin(String(formData.get("email") ?? ""), String(formData.get("password") ?? ""));
  redirect("/admin?notice=Signed+in");
}

export async function adminLogoutAction() {
  await signOutAdmin();
  redirect("/admin?notice=Signed+out");
}

export async function createCategoryAction(formData: FormData) {
  const { employee } = await requireAdminPermission("catalog.manage");
  const name = String(formData.get("name") ?? "").trim();
  if (!name) {
    redirect("/admin?error=Category+name+is+required");
  }

  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  const imageUrl = String(formData.get("imageUrl") ?? "").trim() || undefined;
  const timestamp = now();

  if (usePg()) {
    const id = randomUUID();
    await pgCreateCategory({
      id, organizationId: "org_casualwear", name, slug,
      sortOrder: 0, imageUrl,
    });
    await pgInsertAuditEvent("org_casualwear", null, employee.id, "category", id, "catalog_update", { action: "created", name });
  } else {
    await mutateStore((store) => {
      store.categories.push({
        id: randomUUID(),
        organizationId: store.organization.id,
        name,
        slug,
        parentCategoryId: undefined,
        sortOrder: store.categories.length + 1,
        imageUrl,
        createdAt: timestamp,
        updatedAt: timestamp,
      });
      store.transactionEventPlaceholders.unshift({
        id: randomUUID(),
        transactionId: "txn_admin_catalog_placeholder",
        eventKind: "catalog_update",
        actorEmployeeId: employee.id,
        notes: `Created category ${name}`,
        payload: { entity: "category" },
        createdAt: timestamp,
      });
    });
  }

  revalidatePath("/admin");
  redirect("/admin?notice=Category+created");
}

export async function createProductAction(formData: FormData) {
  const { employee } = await requireAdminPermission("catalog.manage");
  const name = String(formData.get("name") ?? "").trim();
  const categoryId = String(formData.get("categoryId") ?? "");
  const sku = String(formData.get("sku") ?? "").trim();
  const variantName = String(formData.get("variantName") ?? "Default").trim();
  const price = Number(formData.get("price") ?? 0);

  if (!name || !categoryId || !sku || Number.isNaN(price) || price <= 0) {
    redirect("/admin?error=Product+name,+category,+SKU,+and+price+are+required");
  }

  const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  const timestamp = now();
  const productId = randomUUID();
  const variantId = randomUUID();

  if (usePg()) {
    const orgId = "org_casualwear";
    await pgCreateProduct({
      id: productId, organizationId: orgId, categoryId, name, slug,
      description: String(formData.get("description") ?? "").trim() || undefined,
      imageUrl: String(formData.get("imageUrl") ?? "").trim() || undefined,
      isActive: true, isTouchFavorite: formData.get("isTouchFavorite") === "on",
      defaultVariantId: variantId, modifierGroupIds: [],
    });
    await pgCreateVariant({
      id: variantId, organizationId: orgId, productId, sku,
      barcode: String(formData.get("barcode") ?? "").trim() || undefined,
      name: variantName,
      sizeLabel: String(formData.get("sizeLabel") ?? "").trim() || undefined,
      colorLabel: String(formData.get("colorLabel") ?? "").trim() || undefined,
      price, cost: Number(formData.get("cost") ?? 0) || undefined,
      compareAtPrice: Number(formData.get("compareAtPrice") ?? 0) || undefined,
      isActive: true,
    });
    await pgCreateInventoryLevel({
      id: randomUUID(), organizationId: orgId, locationId: "loc_bellflower",
      productVariantId: variantId,
      onHand: Number(formData.get("openingStock") ?? 0) || 0,
      reserved: 0, reorderPoint: Number(formData.get("reorderPoint") ?? 0) || 0,
    });
    await pgInsertAuditEvent(orgId, null, employee.id, "product", productId, "catalog_update", { action: "created", name, sku });
  } else {
    await mutateStore((store) => {
      store.products.push({
        id: productId, organizationId: store.organization.id, categoryId, name, slug,
        description: String(formData.get("description") ?? "").trim() || undefined,
        imageUrl: String(formData.get("imageUrl") ?? "").trim() || undefined,
        isActive: true, isTouchFavorite: formData.get("isTouchFavorite") === "on",
        defaultVariantId: variantId, modifierGroupIds: [],
        createdAt: timestamp, updatedAt: timestamp,
      });
      store.variants.push({
        id: variantId, organizationId: store.organization.id, productId, sku,
        barcode: String(formData.get("barcode") ?? "").trim() || undefined,
        name: variantName,
        sizeLabel: String(formData.get("sizeLabel") ?? "").trim() || undefined,
        colorLabel: String(formData.get("colorLabel") ?? "").trim() || undefined,
        price, cost: Number(formData.get("cost") ?? 0) || undefined,
        compareAtPrice: Number(formData.get("compareAtPrice") ?? 0) || undefined,
        isActive: true, createdAt: timestamp, updatedAt: timestamp,
      });
      const locationId = store.locations[0]?.id;
      if (locationId) {
        store.inventory.push({
          id: randomUUID(), organizationId: store.organization.id, locationId,
          productVariantId: variantId,
          onHand: Number(formData.get("openingStock") ?? 0) || 0,
          reserved: 0, reorderPoint: Number(formData.get("reorderPoint") ?? 0) || 0,
          createdAt: timestamp, updatedAt: timestamp,
        });
      }
      store.transactionEventPlaceholders.unshift({
        id: randomUUID(), transactionId: "txn_admin_catalog_placeholder",
        eventKind: "catalog_update", actorEmployeeId: employee.id,
        notes: `Created product ${name}`, payload: { entity: "product", sku },
        createdAt: timestamp,
      });
    });
  }

  revalidatePath("/admin");
  redirect("/admin?notice=Product+created");
}

export async function adjustInventoryAction(formData: FormData) {
  const { employee } = await requireAdminPermission("inventory.adjust");
  const inventoryLevelId = String(formData.get("inventoryLevelId") ?? "");
  const delta = Number(formData.get("delta") ?? 0);
  const reason = String(formData.get("reason") ?? "").trim();

  if (!inventoryLevelId || !reason || Number.isNaN(delta) || delta === 0) {
    redirect("/admin?error=Inventory+adjustment+needs+row,+delta,+and+reason");
  }

  if (usePg()) {
    const { level } = await pgAdjustInventory(inventoryLevelId, delta, employee.id, reason);
    await pgInsertAuditEvent(level.organizationId, level.locationId, employee.id, "inventory_level", inventoryLevelId, "inventory_adjustment", { delta, reason });
  } else {
    await mutateStore((store) => {
      const timestamp = now();
      const inventoryRow = store.inventory.find((entry) => entry.id === inventoryLevelId);
      if (!inventoryRow) {
        redirect("/admin?error=Inventory+row+not+found");
      }
      inventoryRow.onHand = Math.max(0, inventoryRow.onHand + delta);
      inventoryRow.updatedAt = timestamp;
      store.inventoryAdjustments.unshift({
        id: randomUUID(), inventoryLevelId: inventoryRow.id,
        productVariantId: inventoryRow.productVariantId, locationId: inventoryRow.locationId,
        employeeId: employee.id, reason, delta, resultingOnHand: inventoryRow.onHand, createdAt: timestamp,
      });
      store.transactionEventPlaceholders.unshift({
        id: randomUUID(), transactionId: "txn_inventory_placeholder",
        eventKind: "inventory_adjustment", actorEmployeeId: employee.id,
        notes: `${reason} (${delta > 0 ? "+" : ""}${delta})`,
        payload: { inventory_level_id: inventoryRow.id }, createdAt: timestamp,
      });
    });
  }

  revalidatePath("/admin");
  redirect("/admin?notice=Inventory+updated");
}

export async function createEmployeeAction(formData: FormData) {
  const { employee } = await requireAdminPermission("employee.manage");
  const firstName = String(formData.get("firstName") ?? "").trim();
  const lastName = String(formData.get("lastName") ?? "").trim();
  const roleKey = String(formData.get("roleKey") ?? "cashier") as RoleKey;
  const pin = String(formData.get("pin") ?? "").trim();

  if (!firstName || !lastName || !/^\d{4}$/.test(pin)) {
    redirect("/admin?error=Employee+needs+name+and+4-digit+PIN");
  }

  if (!canManageEmployeeRole(employee.roleKey, roleKey)) {
    redirect("/admin?error=You+cannot+provision+that+role");
  }

  const email = String(formData.get("email") ?? "").trim().toLowerCase() || undefined;
  const password = String(formData.get("password") ?? "").trim();

  if (["owner", "manager"].includes(roleKey) && !password) {
    redirect("/admin?error=Admin-capable+roles+need+a+password");
  }

  if (usePg()) {
    const employeeId = randomUUID();
    const orgId = "org_casualwear";
    await pgCreateEmployee({
      id: employeeId, organizationId: orgId, roleKey, firstName, lastName,
      displayName: `${firstName} ${lastName[0] ?? ""}.`.trim(),
      email, pinHash: hashSecret(pin),
      passwordHash: password ? hashSecret(password) : undefined,
      pinHint: `4-digit ${roleKey.replace("_", " ")} PIN`,
      isActive: true, locationIds: ["loc_bellflower"],
    });
    await pgInsertAuditEvent(orgId, null, employee.id, "employee", employeeId, "catalog_update", { action: "created_employee", name: `${firstName} ${lastName}` });
  } else {
    await mutateStore((store) => {
      const timestamp = now();
      const employeeId = randomUUID();
      store.employees.push({
        id: employeeId, organizationId: store.organization.id,
        locationIds: [store.locations[0].id], roleKey, firstName, lastName,
        displayName: `${firstName} ${lastName[0] ?? ""}.`.trim(),
        email, pinHint: `4-digit ${roleKey.replace("_", " ")} PIN`,
        isActive: true, createdAt: timestamp, updatedAt: timestamp,
      });
      store.authCredentials.push({
        employeeId, email,
        passwordHash: password ? hashSecret(password) : undefined,
        pinHash: hashSecret(pin),
        passwordLastRotatedAt: password ? timestamp : undefined,
        pinLastRotatedAt: timestamp,
      });
    });
  }

  revalidatePath("/admin");
  redirect("/admin?notice=Employee+created");
}

export async function toggleEmployeeAction(formData: FormData) {
  const { employee: actor } = await requireAdminPermission("employee.manage");
  const employeeId = String(formData.get("employeeId") ?? "");

  if (usePg()) {
    const target = await pgReadEmployeeById(employeeId);
    if (!target) redirect("/admin?error=Employee+not+found");
    if (!canManageEmployeeRole(actor.roleKey, target!.roleKey)) {
      redirect("/admin?error=You+cannot+change+that+employee");
    }
    await pgToggleEmployee(employeeId);
  } else {
    await mutateStore((store) => {
      const employee = store.employees.find((entry) => entry.id === employeeId);
      if (!employee) redirect("/admin?error=Employee+not+found");
      if (!canManageEmployeeRole(actor.roleKey, employee!.roleKey)) {
        redirect("/admin?error=You+cannot+change+that+employee");
      }
      employee!.isActive = !employee!.isActive;
      employee!.updatedAt = now();
    });
  }

  revalidatePath("/admin");
  redirect("/admin?notice=Employee+status+updated");
}
