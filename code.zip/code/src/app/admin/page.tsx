import { AppNav } from "@/components/layout/app-nav";
import { AdminConsole } from "@/components/admin/admin-console";
import { PageShell } from "@/components/ui/page-shell";
import { adminLoginAction } from "@/app/admin/actions";
import { getAdminSession } from "@/lib/auth/session";
import { readStore } from "@/lib/persistence/store";

export default async function AdminPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const session = await getAdminSession();
  const store = await readStore();
  const notice = typeof params.notice === "string" ? params.notice.replaceAll("+", " ") : undefined;
  const error = typeof params.error === "string" ? params.error.replaceAll("+", " ") : undefined;

  return (
    <PageShell
      eyebrow="Admin"
      title="Catalog, inventory, and staff foundations"
      description="The admin side now runs on a local persistence/auth foundation: boring file-backed CRUD today, clean seam for Postgres + proper auth tomorrow."
    >
      <AppNav />
      {session ? (
        <AdminConsole
          store={store}
          adminName={session.employee.displayName}
          adminRole={session.employee.roleKey}
          notice={notice}
          error={error}
        />
      ) : (
        <section className="card max-w-xl px-6 py-6">
          <h2 className="text-xl font-semibold">Admin sign-in</h2>
          <p className="mt-2 text-sm text-zinc-600">Local milestone auth for owners/managers. Use owner@swiftpos.local / ownerpass or manager@swiftpos.local / managerpass.</p>
          <form action={adminLoginAction} className="mt-5 grid gap-3">
            <label className="grid gap-1 text-sm font-medium text-zinc-700">
              <span>Email</span>
              <input name="email" type="email" className="rounded-2xl border border-zinc-300 bg-white px-4 py-3" defaultValue="owner@swiftpos.local" />
            </label>
            <label className="grid gap-1 text-sm font-medium text-zinc-700">
              <span>Password</span>
              <input name="password" type="password" className="rounded-2xl border border-zinc-300 bg-white px-4 py-3" defaultValue="ownerpass" />
            </label>
            <button className="touch-button rounded-2xl bg-zinc-900 px-5 text-sm font-semibold text-white">Sign in</button>
          </form>
          {notice ? <p className="mt-4 rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{notice}</p> : null}
          {error ? <p className="mt-4 rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-700">{error}</p> : null}
        </section>
      )}
    </PageShell>
  );
}
