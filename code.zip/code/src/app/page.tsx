import { AppNav } from "@/components/layout/app-nav";
import { PageShell } from "@/components/ui/page-shell";
import { SectionCard } from "@/components/ui/section-card";
import { organization } from "@/lib/data/mock-data";
import { schemaSummary } from "@/lib/db/schema-summary";

const milestones = [
  {
    title: "Milestone 0 foundations",
    items: [
      "Next.js + TypeScript web-first scaffold",
      "Org/location/employee/role direction",
      "Design primitives for register/admin shells",
      "Postgres schema + RLS direction docs",
      "Audit/event logging placeholders",
    ],
  },
  {
    title: "Milestone 1 foundations",
    items: [
      "Categories, products, variants, modifiers",
      "Inventory per location",
      "Employee PIN login direction",
      "Schema room for transaction tenders, events, and exceptions",
    ],
  },
];

export default function HomePage() {
  return (
    <PageShell
      eyebrow="SwiftPOS"
      title="Casualwear MVP foundation"
      description="A disciplined Milestone 1 foundation: stable web-first scaffolding, local persistence, real starter auth/session flows, believable admin CRUD, and explicit room for split tender and transaction integrity."
    >
      <AppNav />

      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <SectionCard title="Project intent" description="This starter intentionally stops before checkout, reporting, accounting, payroll, or e-commerce.">
          <div className="space-y-4 text-sm leading-6 text-zinc-700">
            <p>
              <strong>{organization.name}</strong> is modeled as a single retail organization targeting a touchscreen register and tablet browser workflow.
            </p>
            <p>
              The foundation prioritizes boring reliability: explicit roles, typed domain records, configuration-driven approval thresholds, and documented database structure.
            </p>
          </div>
        </SectionCard>

        <SectionCard title="Schema coverage" description="What already has a seat at the table.">
          <div className="space-y-4">
            {Object.entries(schemaSummary).map(([group, tables]) => (
              <div key={group}>
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-zinc-500">{group}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {tables.map((table) => (
                    <span key={table} className="rounded-full bg-zinc-100 px-3 py-1 text-sm font-medium text-zinc-700">
                      {table}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {milestones.map((milestone) => (
          <SectionCard key={milestone.title} title={milestone.title}>
            <ul className="space-y-3 text-sm text-zinc-700">
              {milestone.items.map((item) => (
                <li key={item} className="flex gap-3">
                  <span className="mt-1 h-2.5 w-2.5 rounded-full bg-teal-600" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </SectionCard>
        ))}
      </div>
    </PageShell>
  );
}
