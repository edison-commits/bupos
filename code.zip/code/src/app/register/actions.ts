"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireRegisterPermission } from "@/lib/authz";
import { getRegisterSession, signInRegister, signOutRegister } from "@/lib/auth/session";
import { mutateStore } from "@/lib/persistence/store";
import {
  pgOpenShift,
  pgCloseShift,
  pgInsertAuditEvent,
} from "@/lib/persistence/postgres-store";

const usePg = () => !!process.env.USE_POSTGRES;

export async function registerLoginAction(formData: FormData) {
  await signInRegister(String(formData.get("pin") ?? ""), String(formData.get("locationId") ?? ""));
  revalidatePath("/register");
  redirect("/register?notice=Register+session+opened");
}

export async function openShiftAction(formData: FormData) {
  const context = await requireRegisterPermission("register.open");
  const openingFloat = Number(formData.get("openingFloat") ?? 0);
  const openedNote = String(formData.get("openedNote") ?? "").trim();

  if (Number.isNaN(openingFloat) || openingFloat < 0) {
    redirect("/register?error=Opening+float+must+be+0+or+greater");
  }

  if (usePg()) {
    if (context.registerSession.activeShiftId) {
      redirect("/register?error=Shift+already+open");
    }
    const shiftId = randomUUID();
    await pgOpenShift({
      id: shiftId, locationId: context.location.id,
      employeeId: context.employee.id,
      registerSessionId: context.registerSession.id,
      openingFloat, openedNote: openedNote || undefined,
    });
    await pgInsertAuditEvent(
      context.employee.organizationId, context.location.id, context.employee.id,
      "shift", shiftId, "shift_opened",
      { register_session_id: context.registerSession.id, opening_float: openingFloat.toFixed(2) },
    );
  } else {
    await mutateStore((store) => {
      const timestamp = new Date().toISOString();
      const registerSession = store.registerSessions.find((entry) => entry.id === context.registerSession.id);
      if (!registerSession || registerSession.status !== "active") {
        redirect("/register?error=Register+session+not+available");
      }
      if (registerSession.activeShiftId) {
        redirect("/register?error=Shift+already+open");
      }
      const shiftId = randomUUID();
      store.shifts.unshift({
        id: shiftId, locationId: context.location.id,
        employeeId: context.employee.id,
        registerSessionId: registerSession.id,
        status: "open", openedAt: timestamp,
        openingFloat, openedNote: openedNote || undefined,
      });
      registerSession.activeShiftId = shiftId;
      store.transactionEventPlaceholders.unshift({
        id: randomUUID(), transactionId: "txn_register_shift_placeholder",
        eventKind: "shift_opened", actorEmployeeId: context.employee.id,
        notes: `Shift opened by ${context.employee.displayName}`,
        payload: {
          register_session_id: registerSession.id, shift_id: shiftId,
          opening_float: openingFloat.toFixed(2),
        },
        createdAt: timestamp,
      });
    });
  }

  revalidatePath("/register");
  redirect("/register?notice=Shift+opened");
}

export async function closeShiftAction(formData: FormData) {
  const context = await requireRegisterPermission("register.open");
  const closingExpectedCash = Number(formData.get("closingExpectedCash") ?? 0);
  const closingDeclaredCash = Number(formData.get("closingDeclaredCash") ?? 0);
  const closedNote = String(formData.get("closedNote") ?? "").trim();

  if (Number.isNaN(closingExpectedCash) || Number.isNaN(closingDeclaredCash) || closingExpectedCash < 0 || closingDeclaredCash < 0) {
    redirect("/register?error=Closing+cash+amounts+must+be+0+or+greater");
  }

  if (usePg()) {
    if (!context.registerSession.activeShiftId) {
      redirect("/register?error=No+active+shift+to+close");
    }
    const shift = await pgCloseShift(context.registerSession.activeShiftId, context.registerSession.id, {
      closingExpectedCash, closingDeclaredCash, closedNote: closedNote || undefined,
    });
    await pgInsertAuditEvent(
      context.employee.organizationId, context.location.id, context.employee.id,
      "shift", shift.id, "shift_closed",
      {
        register_session_id: context.registerSession.id,
        expected_cash: closingExpectedCash.toFixed(2),
        declared_cash: closingDeclaredCash.toFixed(2),
        variance: (shift.closingVariance ?? 0).toFixed(2),
      },
    );
  } else {
    await mutateStore((store) => {
      const timestamp = new Date().toISOString();
      const registerSession = store.registerSessions.find((entry) => entry.id === context.registerSession.id);
      if (!registerSession?.activeShiftId) {
        redirect("/register?error=No+active+shift+to+close");
      }
      const shift = store.shifts.find((entry) => entry.id === registerSession.activeShiftId && entry.status === "open");
      if (!shift) {
        redirect("/register?error=Shift+not+found");
      }
      shift.status = "closed";
      shift.closedAt = timestamp;
      shift.closingExpectedCash = closingExpectedCash;
      shift.closingDeclaredCash = closingDeclaredCash;
      shift.closingVariance = Number((closingDeclaredCash - closingExpectedCash).toFixed(2));
      shift.closedNote = closedNote || undefined;
      registerSession.activeShiftId = undefined;
      store.transactionEventPlaceholders.unshift({
        id: randomUUID(), transactionId: "txn_register_shift_placeholder",
        eventKind: "shift_closed", actorEmployeeId: context.employee.id,
        notes: `Shift closed by ${context.employee.displayName}`,
        payload: {
          register_session_id: registerSession.id, shift_id: shift.id,
          expected_cash: closingExpectedCash.toFixed(2),
          declared_cash: closingDeclaredCash.toFixed(2),
          variance: shift.closingVariance.toFixed(2),
        },
        createdAt: timestamp,
      });
    });
  }

  revalidatePath("/register");
  redirect("/register?notice=Shift+closed");
}

export async function registerLogoutAction() {
  const session = await getRegisterSession();
  if (!session) {
    redirect("/register");
  }

  await signOutRegister();
  revalidatePath("/register");
  redirect("/register?notice=Register+session+closed");
}
