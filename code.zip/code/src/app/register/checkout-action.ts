"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireRegisterPermission } from "@/lib/authz";
import { mutateStore } from "@/lib/persistence/store";
import pool from "@/lib/db";
import type { TenderType } from "@/lib/domain/types";
import type { Cart, CheckoutResult } from "@/lib/cart/types";
import { computeTotals, checkOutCart } from "@/lib/cart/cart";

const usePg = () => !!process.env.USE_POSTGRES;

export async function checkoutAction(cart: Cart, tenderType: TenderType, amountTendered: number): Promise<CheckoutResult> {
  const context = await requireRegisterPermission("register.open");

  if (cart.status !== "open" || cart.items.length === 0) {
    redirect("/register?error=Cart+is+empty+or+already+checked+out");
  }

  const totals = computeTotals(cart);

  if (amountTendered < totals.grandTotal && tenderType === "cash") {
    redirect("/register?error=Insufficient+tender+amount");
  }

  const changeDue = tenderType === "cash" ? Number((amountTendered - totals.grandTotal).toFixed(2)) : 0;
  const transactionId = randomUUID();

  if (usePg()) {
    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      await client.query(
        `INSERT INTO transactions (id, organization_id, location_id, register_session_id, employee_id, cart_snapshot, subtotal, discount_total, tax_total, grand_total, tender_type, amount_tendered, change_due, status)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, 'completed')`,
        [
          transactionId, context.employee.organizationId, context.location.id,
          context.registerSession.id, context.employee.id,
          JSON.stringify(checkOutCart(cart)),
          totals.subtotal, totals.discountTotal, totals.taxTotal, totals.grandTotal,
          tenderType, amountTendered, changeDue,
        ],
      );

      await client.query(
        `INSERT INTO transaction_tenders (id, transaction_id, tender_type, amount, metadata)
         VALUES ($1, $2, $3, $4, $5)`,
        [randomUUID(), transactionId, tenderType, amountTendered, JSON.stringify({ change_due: changeDue.toFixed(2) })],
      );

      await client.query(
        `INSERT INTO transaction_events (id, transaction_id, actor_employee_id, event_kind, notes, payload)
         VALUES ($1, $2, $3, 'transaction_placeholder', $4, $5)`,
        [
          randomUUID(), transactionId, context.employee.id,
          `Checkout by ${context.employee.displayName}`,
          JSON.stringify({
            location_id: context.location.id,
            register_session_id: context.registerSession.id,
            item_count: totals.itemCount,
            grand_total: totals.grandTotal.toFixed(2),
          }),
        ],
      );

      // Decrement inventory for each item
      for (const item of cart.items) {
        await client.query(
          `UPDATE inventory_levels SET on_hand = GREATEST(0, on_hand - $1), updated_at = now()
           WHERE product_variant_id = $2 AND location_id = $3`,
          [item.quantity, item.productVariantId, context.location.id],
        );
      }

      await client.query("COMMIT");
    } catch (e) {
      await client.query("ROLLBACK");
      throw e;
    } finally {
      client.release();
    }
  } else {
    await mutateStore((store) => {
      const timestamp = new Date().toISOString();

      store.transactionTenderPlaceholders.unshift({
        id: randomUUID(), transactionId, tenderType, amount: amountTendered,
        metadata: { change_due: changeDue.toFixed(2) },
      });

      store.transactionEventPlaceholders.unshift({
        id: randomUUID(), transactionId,
        eventKind: "transaction_placeholder",
        actorEmployeeId: context.employee.id,
        notes: `Checkout by ${context.employee.displayName}`,
        payload: {
          location_id: context.location.id,
          register_session_id: context.registerSession.id,
          item_count: String(totals.itemCount),
          grand_total: totals.grandTotal.toFixed(2),
        },
        createdAt: timestamp,
      });

      // Decrement inventory
      for (const item of cart.items) {
        const inv = store.inventory.find(
          (i) => i.productVariantId === item.productVariantId && i.locationId === context.location.id,
        );
        if (inv) {
          inv.onHand = Math.max(0, inv.onHand - item.quantity);
          inv.updatedAt = timestamp;
        }
      }
    });
  }

  revalidatePath("/register");
  return { transactionId, cartId: cart.id, grandTotal: totals.grandTotal, tenderType, amountTendered, changeDue };
}
