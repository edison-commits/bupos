import type { InputHTMLAttributes } from "react";
import { adminLogoutAction, adjustInventoryAction, createCategoryAction, createEmployeeAction, createProductAction, toggleEmployeeAction } from "@/app/admin/actions";
import { SectionCard } from "@/components/ui/section-card";
import { canManageEmployeeRole } from "@/lib/authz";
import { hasPermission, roleDefinitions } from "@/lib/domain/permissions";
import type { RoleKey } from "@/lib/domain/types";
import type { LocalStoreData } from "@/lib/persistence/types";
import { formatDateTime } from "@/lib/utils/date";

export function AdminConsole({
  store,
  adminName,
  adminRole,
  notice,
  error,
}: {
  store: LocalStoreData;
  adminName: string;
  adminRole: RoleKey;
  notice?: string;
  error?: string;
}) {
  const canManageCatalog = hasPermission(adminRole, "catalog.manage");
  const canAdjustInventory = hasPermission(adminRole, "inventory.adjust");
  const canManageEmployees = hasPermission(adminRole, "employee.manage");
  const manageableRoles = roleDefinitions.filter((role) => canManageEmployeeRole(adminRole, role.key));

  const productRows = store.products.map((product) => ({
    ...product,
    category: store.categories.find((entry) => entry.id === product.categoryId),
    variants: store.variants.filter((entry) => entry.productId === product.id),
  }));

  const inventoryRows = store.inventory.map((row) => ({
    ...row,
    variant: store.variants.find((entry) => entry.id === row.productVariantId),
    location: store.locations.find((entry) => entry.id === row.locationId),
  }));

  return (
    <div className="grid gap-6">
      <SectionCard title="Admin session" description="Local cookie session + file-backed store for Milestone 1 development. This stays intentionally boring so Postgres/Auth can replace it cleanly later.">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm text-zinc-500">Signed in as</p>
            <p className="text-xl font-semibold">{adminName}</p>
            <p className="text-sm text-zinc-600">{adminRole} · demo admin logins: owner@swiftpos.local / ownerpass · manager@swiftpos.local / managerpass</p>
          </div>
          <form action={adminLogoutAction}>
            <button className="touch-button rounded-2xl bg-zinc-900 px-5 text-sm font-semibold text-white">Sign out</button>
          </form>
        </div>
        {notice ? <p className="mt-4 rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{notice}</p> : null}
        {error ? <p className="mt-4 rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-700">{error}</p> : null}
      </SectionCard>

      <div className="grid gap-6 xl:grid-cols-2">
        <SectionCard title="Catalog snapshot" description="Starter CRUD for categories and products. Variants are created alongside their base product so the data model stays ready for scanner/touch workflows.">
          <div className="grid gap-3 md:grid-cols-3">
            <Metric label="Categories" value={String(store.categories.length)} />
            <Metric label="Products" value={String(store.products.length)} />
            <Metric label="Variants" value={String(store.variants.length)} />
          </div>
          <div className="mt-5 grid gap-3">
            {productRows.map((product) => (
              <div key={product.id} className="rounded-2xl border border-zinc-200 px-4 py-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-semibold">{product.name}</h3>
                    <p className="text-sm text-zinc-600">{product.category?.name ?? "Uncategorized"}</p>
                  </div>
                  <span className="rounded-full bg-zinc-100 px-3 py-1 text-xs font-medium text-zinc-700">{product.variants.length} variants</span>
                </div>
                <div className="mt-3 flex flex-wrap gap-2 text-xs text-zinc-500">
                  {product.variants.map((variant) => (
                    <span key={variant.id} className="rounded-full bg-teal-50 px-3 py-1 text-teal-800">
                      {variant.sku} · ${variant.price.toFixed(2)}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Create category" description="Minimal starter form for category structure.">
          {canManageCatalog ? (
            <form action={createCategoryAction} className="grid gap-3">
              <Input name="name" label="Category name" placeholder="Outerwear" />
              <Input name="imageUrl" label="Image URL" placeholder="https://..." />
              <button className="touch-button rounded-2xl bg-teal-700 px-5 text-sm font-semibold text-white">Add category</button>
            </form>
          ) : (
            <LockedMessage message="This role can view catalog structure but cannot change it." />
          )}
        </SectionCard>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <SectionCard title="Create product + starter variant" description="Adds a product, its default variant, and an initial inventory row in one boring reliable step.">
          {canManageCatalog ? (
            <form action={createProductAction} className="grid gap-3 md:grid-cols-2">
              <Input name="name" label="Product name" placeholder="Classic Zip Hoodie" />
              <label className="grid gap-1 text-sm font-medium text-zinc-700">
                <span>Category</span>
                <select name="categoryId" className="rounded-2xl border border-zinc-300 bg-white px-4 py-3">
                  {store.categories.map((category) => (
                    <option key={category.id} value={category.id}>{category.name}</option>
                  ))}
                </select>
              </label>
              <Input name="sku" label="SKU" placeholder="TOP-HOOD-M-BLK" />
              <Input name="variantName" label="Variant label" placeholder="Medium / Black" />
              <Input name="price" label="Price" type="number" step="0.01" placeholder="48" />
              <Input name="cost" label="Cost" type="number" step="0.01" placeholder="18" />
              <Input name="barcode" label="Barcode" placeholder="0123456789012" />
              <Input name="sizeLabel" label="Size" placeholder="M" />
              <Input name="colorLabel" label="Color" placeholder="Black" />
              <Input name="openingStock" label="Opening stock" type="number" placeholder="12" />
              <Input name="reorderPoint" label="Reorder point" type="number" placeholder="4" />
              <Input name="imageUrl" label="Image URL" placeholder="https://..." />
              <label className="md:col-span-2 grid gap-1 text-sm font-medium text-zinc-700">
                <span>Description</span>
                <textarea name="description" className="min-h-28 rounded-2xl border border-zinc-300 bg-white px-4 py-3" placeholder="Touch-friendly featured product for the register grid." />
              </label>
              <label className="inline-flex items-center gap-3 text-sm font-medium text-zinc-700 md:col-span-2">
                <input name="isTouchFavorite" type="checkbox" className="h-4 w-4 rounded border-zinc-300" />
                Mark as touch favorite
              </label>
              <button className="touch-button rounded-2xl bg-zinc-900 px-5 text-sm font-semibold text-white md:col-span-2">Create product</button>
            </form>
          ) : (
            <LockedMessage message="This role cannot create or edit products." />
          )}
        </SectionCard>

        <SectionCard title="Inventory foundations" description="Starter inventory adjustments create a durable adjustment log now, without dragging checkout into scope.">
          <div className="space-y-3">
            {inventoryRows.map((row) => (
              <div key={row.id} className="rounded-2xl border border-zinc-200 px-4 py-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h3 className="font-semibold">{row.variant?.name ?? row.productVariantId}</h3>
                    <p className="text-sm text-zinc-600">{row.variant?.sku ?? "No SKU"} · {row.location?.name}</p>
                  </div>
                  <span className="rounded-full bg-zinc-100 px-3 py-1 text-sm font-semibold text-zinc-800">On hand {row.onHand}</span>
                </div>
              </div>
            ))}
          </div>
          {canAdjustInventory ? (
            <form action={adjustInventoryAction} className="mt-5 grid gap-3 md:grid-cols-3">
              <label className="grid gap-1 text-sm font-medium text-zinc-700 md:col-span-2">
                <span>Inventory row</span>
                <select name="inventoryLevelId" className="rounded-2xl border border-zinc-300 bg-white px-4 py-3">
                  {inventoryRows.map((row) => (
                    <option key={row.id} value={row.id}>{row.variant?.sku ?? row.id} · on hand {row.onHand}</option>
                  ))}
                </select>
              </label>
              <Input name="delta" label="Delta" type="number" placeholder="-1" />
              <label className="grid gap-1 text-sm font-medium text-zinc-700 md:col-span-3">
                <span>Reason</span>
                <input name="reason" className="rounded-2xl border border-zinc-300 bg-white px-4 py-3" placeholder="Cycle count correction" />
              </label>
              <button className="touch-button rounded-2xl bg-amber-600 px-5 text-sm font-semibold text-white md:col-span-3">Record adjustment</button>
            </form>
          ) : (
            <div className="mt-5"><LockedMessage message="This role can review inventory but cannot post adjustments." /></div>
          )}
          <div className="mt-5 space-y-2">
            <h3 className="text-sm font-semibold uppercase tracking-[0.18em] text-zinc-500">Recent adjustments</h3>
            {store.inventoryAdjustments.length === 0 ? (
              <p className="text-sm text-zinc-600">No inventory adjustments yet.</p>
            ) : (
              store.inventoryAdjustments.slice(0, 5).map((entry) => (
                <div key={entry.id} className="rounded-2xl bg-zinc-50 px-4 py-3 text-sm text-zinc-700">
                  {entry.reason} · {entry.delta > 0 ? "+" : ""}{entry.delta} · resulting {entry.resultingOnHand} · {formatDateTime(entry.createdAt)}
                </div>
              ))
            )}
          </div>
        </SectionCard>
      </div>

      <div className="grid gap-6 xl:grid-cols-2">
        <SectionCard title="Staff foundations" description="Admin users can create employees with PIN credentials now. Passwords remain optional except for actual admin login roles.">
          <div className="space-y-3">
            {store.employees.map((employee) => {
              const canManageThisEmployee = canManageEmployees && canManageEmployeeRole(adminRole, employee.roleKey);
              return (
                <div key={employee.id} className="rounded-2xl border border-zinc-200 px-4 py-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-semibold">{employee.displayName}</h3>
                      <p className="text-sm text-zinc-600">{employee.roleKey} · {employee.email ?? "PIN-only register user"}</p>
                    </div>
                    {canManageThisEmployee ? (
                      <form action={toggleEmployeeAction}>
                        <input type="hidden" name="employeeId" value={employee.id} />
                        <button className={`rounded-full px-3 py-1 text-xs font-semibold text-white ${employee.isActive ? "bg-zinc-800" : "bg-red-700"}`}>
                          {employee.isActive ? "Active" : "Inactive"}
                        </button>
                      </form>
                    ) : (
                      <span className="rounded-full bg-zinc-100 px-3 py-1 text-xs font-semibold text-zinc-600">Locked</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </SectionCard>

        <SectionCard title="Create employee" description="Basic employee provisioning for register and admin roles.">
          {canManageEmployees && manageableRoles.length > 0 ? (
            <form action={createEmployeeAction} className="grid gap-3 md:grid-cols-2">
              <Input name="firstName" label="First name" placeholder="Jordan" />
              <Input name="lastName" label="Last name" placeholder="Lee" />
              <label className="grid gap-1 text-sm font-medium text-zinc-700">
                <span>Role</span>
                <select name="roleKey" className="rounded-2xl border border-zinc-300 bg-white px-4 py-3">
                  {manageableRoles.map((role) => (
                    <option key={role.key} value={role.key}>{role.label}</option>
                  ))}
                </select>
              </label>
              <Input name="pin" label="4-digit PIN" placeholder="4444" />
              <Input name="email" label="Email (optional for cashier)" placeholder="jordan@swiftpos.local" />
              <Input name="password" label="Password (needed for admin login roles)" type="password" placeholder="Temporary password" />
              <button className="touch-button rounded-2xl bg-teal-700 px-5 text-sm font-semibold text-white md:col-span-2">Create employee</button>
            </form>
          ) : (
            <LockedMessage message="This role cannot provision employees." />
          )}
        </SectionCard>
      </div>

      <SectionCard title="Future checkout room kept explicit" description="These tables remain placeholders only. They stay visible so checkout/tenders/exceptions land on an intentional foundation later.">
        <div className="grid gap-3 md:grid-cols-3">
          <Metric label="Tender placeholders" value={String(store.transactionTenderPlaceholders.length)} />
          <Metric label="Event placeholders" value={String(store.transactionEventPlaceholders.length)} />
          <Metric label="Exception placeholders" value={String(store.transactionExceptionPlaceholders.length)} />
        </div>
      </SectionCard>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="kpi rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-4">
      <p className="text-sm text-zinc-500">{label}</p>
      <p className="mt-2 text-3xl font-semibold tracking-tight">{value}</p>
    </div>
  );
}

function Input({ label, ...props }: InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="grid gap-1 text-sm font-medium text-zinc-700">
      <span>{label}</span>
      <input {...props} className="rounded-2xl border border-zinc-300 bg-white px-4 py-3" />
    </label>
  );
}

function LockedMessage({ message }: { message: string }) {
  return <p className="rounded-2xl bg-zinc-100 px-4 py-3 text-sm text-zinc-700">{message}</p>;
}
