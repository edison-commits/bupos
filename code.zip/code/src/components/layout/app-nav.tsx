import Link from "next/link";

const links = [
  { href: "/", label: "Overview" },
  { href: "/register", label: "Register shell" },
  { href: "/admin", label: "Admin shell" },
];

export function AppNav() {
  return (
    <nav className="card flex flex-wrap items-center gap-3 px-4 py-3">
      <span className="rounded-full bg-teal-600 px-3 py-1 text-sm font-semibold text-white">SwiftPOS</span>
      {links.map((link) => (
        <Link
          key={link.href}
          href={link.href}
          className="touch-button inline-flex items-center rounded-full border border-zinc-200 px-4 text-sm font-medium text-zinc-700 transition hover:border-zinc-300 hover:bg-zinc-50"
        >
          {link.label}
        </Link>
      ))}
    </nav>
  );
}
