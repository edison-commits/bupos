import { closeShiftAction, openShiftAction, registerLogoutAction } from "@/app/register/actions";
import { SectionCard } from "@/components/ui/section-card";
import { hasPermission } from "@/lib/domain/permissions";
import type { LocalStoreData, RegisterSessionContext } from "@/lib/persistence/types";
import { formatDateTime } from "@/lib/utils/date";

export function RegisterConsole({
  store,
  context,
  notice,
  error,
}: {
  store: LocalStoreData;
  context: RegisterSessionContext;
  notice?: string;
  error?: string;
}) {
  const canOpenRegister = hasPermission(context.employee.roleKey, "register.open");

  const locationInventory = store.inventory
    .filter((entry) => entry.locationId === context.location.id)
    .map((entry) => ({
      ...entry,
      variant: store.variants.find((variant) => variant.id === entry.productVariantId),
      product: store.products.find((product) => product.id === store.variants.find((variant) => variant.id === entry.productVariantId)?.productId),
    }));

  const recentEvents = store.transactionEventPlaceholders
    .filter((entry) => ["pin_login", "shift_opened", "shift_closed", "register_session_started", "register_session_ended"].includes(entry.eventKind))
    .slice(0, 6)
    .map((entry) => ({
      ...entry,
      employee: store.employees.find((employee) => employee.id === entry.actorEmployeeId),
    }));

  const recentShifts = store.shifts
    .filter((entry) => entry.locationId === context.location.id)
    .slice(0, 5)
    .map((entry) => ({
      ...entry,
      employee: store.employees.find((employee) => employee.id === entry.employeeId),
    }));

  return (
    <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
      <div className="grid gap-6">
        <SectionCard title="Register session" description="PIN login now creates a real persisted register session. That session owns shift state today and will own cart/transaction boundaries next.">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-4">
              <p className="text-sm text-zinc-500">Cashier</p>
              <p className="mt-2 text-2xl font-semibold">{context.employee.displayName}</p>
              <p className="text-sm text-zinc-600">{context.employee.roleKey}</p>
            </div>
            <div className="rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-4">
              <p className="text-sm text-zinc-500">Location</p>
              <p className="mt-2 text-2xl font-semibold">{context.location.name}</p>
              <p className="text-sm text-zinc-600">{context.location.address1}</p>
            </div>
          </div>
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            <Metric label="Register session" value={context.registerSession.status} detail={`Started ${formatDateTime(context.registerSession.startedAt)}`} />
            <Metric label="Shift state" value={context.activeShift ? "open" : "not opened"} detail={context.activeShift ? `Opened ${formatDateTime(context.activeShift.openedAt)}` : "Open shift before cart/tender work lands."} />
            <Metric label="Future cart anchor" value={context.registerSession.lastCartId ?? "pending"} detail="Reserved on register session for next milestone" />
          </div>
          <div className="mt-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div className="text-sm text-zinc-600">
              Session opened {formatDateTime(context.session.createdAt)} · cart, tenders, and transaction exceptions can attach here next without architectural rework.
            </div>
            <form action={registerLogoutAction}>
              <button className="touch-button rounded-2xl bg-zinc-900 px-5 text-sm font-semibold text-white">Close session</button>
            </form>
          </div>
          {notice ? <p className="mt-4 rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800">{notice}</p> : null}
          {error ? <p className="mt-4 rounded-2xl bg-red-50 px-4 py-3 text-sm text-red-700">{error}</p> : null}
        </SectionCard>

        <SectionCard title="Shift lifecycle foundation" description="Shift open/close is now explicit instead of implied by PIN login. That keeps cash-control and later tender reconciliation on a dedicated model.">
          {!canOpenRegister ? (
            <p className="rounded-2xl bg-zinc-100 px-4 py-3 text-sm text-zinc-700">This role can participate in register flows but cannot open or close the register.</p>
          ) : context.activeShift ? (
            <div className="grid gap-4">
              <div className="grid gap-3 md:grid-cols-3">
                <Metric label="Opening float" value={`$${context.activeShift.openingFloat.toFixed(2)}`} detail={context.activeShift.openedNote ?? "No opening note"} />
                <Metric label="Pending exceptions" value={String(context.registerSession.pendingExceptionIds.length)} detail="Reserved for approvals/exceptions" />
                <Metric label="Last transaction" value={context.registerSession.lastTransactionId ?? "pending"} detail="Reserved for checkout milestone" />
              </div>
              <form action={closeShiftAction} className="grid gap-3 md:grid-cols-2">
                <label className="grid gap-1 text-sm font-medium text-zinc-700">
                  <span>Expected closing cash</span>
                  <input name="closingExpectedCash" type="number" step="0.01" defaultValue={context.activeShift.openingFloat.toFixed(2)} className="rounded-2xl border border-zinc-300 bg-white px-4 py-3" />
                </label>
                <label className="grid gap-1 text-sm font-medium text-zinc-700">
                  <span>Declared closing cash</span>
                  <input name="closingDeclaredCash" type="number" step="0.01" defaultValue={context.activeShift.openingFloat.toFixed(2)} className="rounded-2xl border border-zinc-300 bg-white px-4 py-3" />
                </label>
                <label className="grid gap-1 text-sm font-medium text-zinc-700 md:col-span-2">
                  <span>Closing note</span>
                  <textarea name="closedNote" className="min-h-24 rounded-2xl border border-zinc-300 bg-white px-4 py-3" placeholder="Drawer count looks clean. No unresolved variances." />
                </label>
                <button className="touch-button rounded-2xl bg-amber-600 px-5 text-sm font-semibold text-white md:col-span-2">Close shift</button>
              </form>
            </div>
          ) : (
            <form action={openShiftAction} className="grid gap-3 md:grid-cols-2">
              <label className="grid gap-1 text-sm font-medium text-zinc-700">
                <span>Opening float</span>
                <input name="openingFloat" type="number" step="0.01" defaultValue="200.00" className="rounded-2xl border border-zinc-300 bg-white px-4 py-3" />
              </label>
              <label className="grid gap-1 text-sm font-medium text-zinc-700 md:col-span-2">
                <span>Opening note</span>
                <textarea name="openedNote" className="min-h-24 rounded-2xl border border-zinc-300 bg-white px-4 py-3" placeholder="Drawer counted and receipt printer loaded." />
              </label>
              <button className="touch-button rounded-2xl bg-teal-700 px-5 text-sm font-semibold text-white md:col-span-2">Open shift</button>
            </form>
          )}
        </SectionCard>

        <SectionCard title="Touch-ready product surface" description="Still not checkout. This is just the product and stock context a real cart flow will need next.">
          <div className="grid gap-3 md:grid-cols-2">
            {locationInventory.map((row) => (
              <div key={row.id} className="rounded-2xl border border-zinc-200 bg-white px-4 py-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-semibold">{row.product?.name ?? row.variant?.name ?? row.id}</h3>
                    <p className="text-sm text-zinc-600">{row.variant?.name} · {row.variant?.sku}</p>
                  </div>
                  <span className="rounded-full bg-teal-50 px-3 py-1 text-xs font-semibold text-teal-800">{row.onHand} on hand</span>
                </div>
                <div className="mt-3 flex items-center justify-between text-sm text-zinc-600">
                  <span>${row.variant?.price.toFixed(2) ?? "0.00"}</span>
                  <span>Reorder {row.reorderPoint}</span>
                </div>
              </div>
            ))}
          </div>
        </SectionCard>
      </div>

      <div className="grid gap-6">
        <SectionCard title="Approval and tender readiness" description="Configuration is persisted now so the future checkout flow can consume settings instead of inventing them in the UI layer.">
          <div className="grid gap-3">
            {store.registerConfiguration.supportedTenders.map((tender) => (
              <div key={tender} className="flex items-center justify-between rounded-2xl border border-zinc-200 px-4 py-3">
                <span className="font-medium">{tender}</span>
                <span className="text-sm text-zinc-500">Reserved for checkout milestone</span>
              </div>
            ))}
          </div>
          <div className="mt-4 grid gap-3">
            {Object.entries(store.registerConfiguration.approvalThresholds).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between rounded-2xl bg-zinc-50 px-4 py-3 text-sm">
                <span>{key}</span>
                <span className="font-semibold">${value.toFixed(2)}</span>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Recent register accountability events" description="Register sessions and shifts now append structured events. That keeps a clean audit seam for later transaction events and exceptions.">
          <div className="space-y-3">
            {recentEvents.map((entry) => (
              <div key={entry.id} className="rounded-2xl border border-zinc-200 px-4 py-4">
                <p className="font-medium">{entry.employee?.displayName ?? entry.actorEmployeeId}</p>
                <p className="text-sm text-zinc-600">{entry.eventKind.replaceAll("_", " ")} · {entry.notes}</p>
                <p className="mt-2 text-xs uppercase tracking-[0.18em] text-zinc-500">{formatDateTime(entry.createdAt)}</p>
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Recent shifts" description="The persisted shift list is simple on purpose: enough to anchor cash-control and drawer reconciliation before checkout ships.">
          <div className="space-y-3">
            {recentShifts.length === 0 ? (
              <p className="text-sm text-zinc-600">No shifts opened yet.</p>
            ) : (
              recentShifts.map((shift) => (
                <div key={shift.id} className="rounded-2xl border border-zinc-200 px-4 py-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-medium">{shift.employee?.displayName ?? shift.employeeId}</p>
                      <p className="text-sm text-zinc-600">Opened {formatDateTime(shift.openedAt)}</p>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-xs font-semibold ${shift.status === "open" ? "bg-emerald-100 text-emerald-800" : "bg-zinc-100 text-zinc-700"}`}>{shift.status}</span>
                  </div>
                  <div className="mt-3 text-sm text-zinc-600">
                    Float ${shift.openingFloat.toFixed(2)}
                    {typeof shift.closingVariance === "number" ? ` · variance ${shift.closingVariance >= 0 ? "+" : ""}$${shift.closingVariance.toFixed(2)}` : ""}
                  </div>
                </div>
              ))
            )}
          </div>
        </SectionCard>
      </div>
    </div>
  );
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-4">
      <p className="text-sm text-zinc-500">{label}</p>
      <p className="mt-2 text-xl font-semibold">{value}</p>
      <p className="mt-2 text-xs text-zinc-500">{detail}</p>
    </div>
  );
}
