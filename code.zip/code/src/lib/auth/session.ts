import "server-only";

import { randomUUID } from "node:crypto";
import { addDays } from "@/lib/utils/date";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { verifySecret } from "@/lib/auth/crypto";
import { hasPermission } from "@/lib/domain/permissions";
import { mutateStore, readStore } from "@/lib/persistence/store";
import type { AdminSessionContext, RegisterSessionContext, SessionRecord } from "@/lib/persistence/types";

const ADMIN_COOKIE = "swiftpos_admin_session";
const REGISTER_COOKIE = "swiftpos_register_session";

function buildSession(scope: SessionRecord["scope"], employeeId: string, locationId?: string): SessionRecord {
  const now = new Date();
  return {
    id: randomUUID(),
    employeeId,
    scope,
    locationId,
    createdAt: now.toISOString(),
    lastSeenAt: now.toISOString(),
    expiresAt: addDays(now, scope === "admin" ? 7 : 1).toISOString(),
  };
}

async function cookieStore() {
  return cookies();
}

async function resolveSession(scope: SessionRecord["scope"], cookieName: string) {
  const jar = await cookieStore();
  const sessionId = jar.get(cookieName)?.value;

  if (!sessionId) {
    return null;
  }

  const store = await readStore();
  const session = store.sessions.find((entry) => entry.id === sessionId && entry.scope === scope);

  if (!session || new Date(session.expiresAt) < new Date()) {
    return null;
  }

  session.lastSeenAt = new Date().toISOString();

  const employee = store.employees.find((entry) => entry.id === session.employeeId && entry.isActive);
  if (!employee) {
    return null;
  }

  if (scope === "admin") {
    return { session, employee } satisfies AdminSessionContext;
  }

  const location = store.locations.find((entry) => entry.id === session.locationId && entry.isActive);
  if (!location) {
    return null;
  }

  const registerSession = store.registerSessions.find(
    (entry) => entry.authSessionId === session.id && entry.status === "active",
  );
  if (!registerSession) {
    return null;
  }

  const activeShift = registerSession.activeShiftId
    ? store.shifts.find((entry) => entry.id === registerSession.activeShiftId && entry.status === "open") ?? null
    : null;

  return { session, employee, location, registerSession, activeShift } satisfies RegisterSessionContext;
}

export async function getAdminSession() {
  return resolveSession("admin", ADMIN_COOKIE) as Promise<AdminSessionContext | null>;
}

export async function getRegisterSession() {
  return resolveSession("register", REGISTER_COOKIE) as Promise<RegisterSessionContext | null>;
}

export async function signInAdmin(email: string, password: string) {
  const normalizedEmail = email.trim().toLowerCase();

  const session = await mutateStore(async (store) => {
    const credential = store.authCredentials.find((entry) => entry.email?.toLowerCase() === normalizedEmail);
    if (!credential?.passwordHash) {
      return null;
    }

    const employee = store.employees.find((entry) => entry.id === credential.employeeId && entry.isActive);
    if (!employee || !["owner", "manager"].includes(employee.roleKey)) {
      return null;
    }

    if (!verifySecret(password, credential.passwordHash)) {
      return null;
    }

    store.sessions = store.sessions.filter((entry) => !(entry.scope === "admin" && entry.employeeId === employee.id));
    const nextSession = buildSession("admin", employee.id);
    store.sessions.push(nextSession);
    return nextSession;
  });

  if (!session) {
    redirect("/admin?error=Invalid+admin+credentials");
  }

  const jar = await cookieStore();
  jar.set(ADMIN_COOKIE, session.id, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: new Date(session.expiresAt),
  });
}

export async function signInRegister(pin: string, locationId: string) {
  const cleanPin = pin.trim();

  const session = await mutateStore(async (store) => {
    const credential = store.authCredentials.find((entry) => entry.pinHash && verifySecret(cleanPin, entry.pinHash));
    if (!credential) {
      return null;
    }

    const employee = store.employees.find((entry) => entry.id === credential.employeeId && entry.isActive);
    const location = store.locations.find((entry) => entry.id === locationId && entry.isActive);
    if (!employee || !location || !employee.locationIds.includes(locationId)) {
      return null;
    }

    if (!hasPermission(employee.roleKey, "register.pin_login") || !hasPermission(employee.roleKey, "register.open")) {
      return null;
    }

    const timestamp = new Date().toISOString();
    store.sessions = store.sessions.filter((entry) => !(entry.scope === "register" && entry.employeeId === employee.id));
    store.registerSessions = store.registerSessions.filter(
      (entry) => !(entry.employeeId === employee.id && entry.locationId === locationId && entry.status === "active"),
    );

    const nextSession = buildSession("register", employee.id, locationId);
    const registerSessionId = randomUUID();

    store.sessions.push(nextSession);
    store.registerSessions.push({
      id: registerSessionId,
      authSessionId: nextSession.id,
      employeeId: employee.id,
      locationId,
      status: "active",
      startedAt: timestamp,
      pendingExceptionIds: [],
    });
    store.transactionEventPlaceholders.unshift({
      id: randomUUID(),
      transactionId: "txn_register_session_placeholder",
      eventKind: "register_session_started",
      actorEmployeeId: employee.id,
      notes: `Register session started for ${employee.displayName}`,
      payload: { location_id: locationId, register_session_id: registerSessionId },
      createdAt: timestamp,
    });
    store.transactionEventPlaceholders.unshift({
      id: randomUUID(),
      transactionId: "txn_register_session_placeholder",
      eventKind: "pin_login",
      actorEmployeeId: employee.id,
      notes: `Register login for ${employee.displayName}`,
      payload: { location_id: locationId, source: "local-session", register_session_id: registerSessionId },
      createdAt: timestamp,
    });
    return nextSession;
  });

  if (!session) {
    redirect("/register?error=PIN+login+failed");
  }

  const jar = await cookieStore();
  jar.set(REGISTER_COOKIE, session.id, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: new Date(session.expiresAt),
  });
}

export async function signOutAdmin() {
  const jar = await cookieStore();
  const sessionId = jar.get(ADMIN_COOKIE)?.value;

  if (sessionId) {
    await mutateStore((store) => {
      store.sessions = store.sessions.filter((entry) => entry.id !== sessionId);
    });
  }

  jar.delete(ADMIN_COOKIE);
}

export async function signOutRegister() {
  const jar = await cookieStore();
  const sessionId = jar.get(REGISTER_COOKIE)?.value;

  if (sessionId) {
    await mutateStore((store) => {
      const timestamp = new Date().toISOString();
      const authSession = store.sessions.find((entry) => entry.id === sessionId && entry.scope === "register");
      const registerSession = store.registerSessions.find(
        (entry) => entry.authSessionId === sessionId && entry.status === "active",
      );

      if (registerSession) {
        if (registerSession.activeShiftId) {
          const shift = store.shifts.find((entry) => entry.id === registerSession.activeShiftId && entry.status === "open");
          if (shift) {
            shift.status = "closed";
            shift.closedAt = timestamp;
            shift.closingExpectedCash = shift.openingFloat;
            shift.closingDeclaredCash = shift.openingFloat;
            shift.closingVariance = 0;
            shift.closedNote = "Auto-closed because register session ended without manual shift close.";
          }

          store.transactionEventPlaceholders.unshift({
            id: randomUUID(),
            transactionId: "txn_register_shift_placeholder",
            eventKind: "shift_closed",
            actorEmployeeId: registerSession.employeeId,
            notes: "Shift auto-closed during register logout",
            payload: { register_session_id: registerSession.id, auto_closed: "true" },
            createdAt: timestamp,
          });
        }

        registerSession.status = "ended";
        registerSession.endedAt = timestamp;
        registerSession.activeShiftId = undefined;
        store.transactionEventPlaceholders.unshift({
          id: randomUUID(),
          transactionId: "txn_register_session_placeholder",
          eventKind: "register_session_ended",
          actorEmployeeId: registerSession.employeeId,
          notes: "Register session ended",
          payload: { register_session_id: registerSession.id },
          createdAt: timestamp,
        });
      }

      if (authSession) {
        store.sessions = store.sessions.filter((entry) => entry.id !== sessionId);
      }
    });
  }

  jar.delete(REGISTER_COOKIE);
}
