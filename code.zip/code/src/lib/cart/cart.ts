import { randomUUID } from 'node:crypto';
import type { EntityId } from '@/lib/domain/types';
import type { Cart, CartLineItem, CartTotals } from '@/lib/cart/types';

export function createCart(registerSessionId: EntityId, employeeId: EntityId, locationId: EntityId): Cart {
  const ts = new Date().toISOString();
  return {
    id: randomUUID(),
    registerSessionId,
    employeeId,
    locationId,
    items: [],
    discountAmount: 0,
    taxRate: 0,
    status: 'open',
    createdAt: ts,
    updatedAt: ts,
  };
}

export function addItem(cart: Cart, item: Omit<CartLineItem, 'id'>): Cart {
  const existing = cart.items.find(
    (i) => i.productVariantId === item.productVariantId
      && JSON.stringify(i.modifierIds) === JSON.stringify(item.modifierIds),
  );
  if (existing) {
    return {
      ...cart,
      items: cart.items.map((i) =>
        i === existing ? { ...i, quantity: i.quantity + item.quantity } : i,
      ),
      updatedAt: new Date().toISOString(),
    };
  }
  return {
    ...cart,
    items: [...cart.items, { ...item, id: randomUUID() }],
    updatedAt: new Date().toISOString(),
  };
}

export function removeItem(cart: Cart, lineItemId: string): Cart {
  return {
    ...cart,
    items: cart.items.filter((i) => i.id !== lineItemId),
    updatedAt: new Date().toISOString(),
  };
}

export function updateQuantity(cart: Cart, lineItemId: string, quantity: number): Cart {
  if (quantity <= 0) return removeItem(cart, lineItemId);
  return {
    ...cart,
    items: cart.items.map((i) => (i.id === lineItemId ? { ...i, quantity } : i)),
    updatedAt: new Date().toISOString(),
  };
}

export function setDiscount(cart: Cart, discountAmount: number): Cart {
  return { ...cart, discountAmount: Math.max(0, discountAmount), updatedAt: new Date().toISOString() };
}

export function computeTotals(cart: Cart): CartTotals {
  let subtotal = 0;
  let modifiersTotal = 0;
  let itemCount = 0;

  for (const item of cart.items) {
    subtotal += item.unitPrice * item.quantity;
    modifiersTotal += item.modifierTotal * item.quantity;
    itemCount += item.quantity;
  }

  const discountTotal = Math.min(cart.discountAmount, subtotal + modifiersTotal);
  const taxableAmount = subtotal + modifiersTotal - discountTotal;
  const taxTotal = Number((taxableAmount * cart.taxRate).toFixed(2));
  const grandTotal = Number((taxableAmount + taxTotal).toFixed(2));

  return { subtotal, modifiersTotal, discountTotal, taxTotal, grandTotal, itemCount };
}

export function voidCart(cart: Cart): Cart {
  return { ...cart, status: 'voided', updatedAt: new Date().toISOString() };
}

export function checkOutCart(cart: Cart): Cart {
  return { ...cart, status: 'checked_out', updatedAt: new Date().toISOString() };
}
