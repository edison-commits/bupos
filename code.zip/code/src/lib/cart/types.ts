import type { EntityId, TenderType } from '@/lib/domain/types';

export interface CartLineItem {
  id: string;
  productVariantId: EntityId;
  productName: string;
  variantName: string;
  sku: string;
  unitPrice: number;
  quantity: number;
  modifierIds: EntityId[];
  modifierTotal: number;
}

export interface CartTotals {
  subtotal: number;
  modifiersTotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  itemCount: number;
}

export interface Cart {
  id: string;
  registerSessionId: EntityId;
  employeeId: EntityId;
  locationId: EntityId;
  items: CartLineItem[];
  discountAmount: number;
  taxRate: number;
  status: 'open' | 'checked_out' | 'voided';
  createdAt: string;
  updatedAt: string;
}

export interface CheckoutRequest {
  cartId: string;
  tenderType: TenderType;
  amountTendered: number;
  cashGiven?: number;
}

export interface CheckoutResult {
  transactionId: string;
  cartId: string;
  grandTotal: number;
  tenderType: TenderType;
  amountTendered: number;
  changeDue: number;
}
