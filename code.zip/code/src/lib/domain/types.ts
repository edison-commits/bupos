export type EntityId = string;

export type RoleKey =
  | "owner"
  | "manager"
  | "cashier"
  | "inventory_clerk"
  | "support";

export type PermissionKey =
  | "register.open"
  | "register.pin_login"
  | "catalog.manage"
  | "inventory.adjust"
  | "employee.manage"
  | "audit.view"
  | "approval.discount"
  | "approval.void_item"
  | "approval.void_transaction"
  | "approval.store_credit"
  | "approval.price_override";

export type TenderType = "cash" | "card" | "store_credit" | "split";

export type AuditEventKind =
  | "pin_login"
  | "catalog_update"
  | "inventory_adjustment"
  | "manager_override"
  | "shift_opened"
  | "shift_closed"
  | "register_session_started"
  | "register_session_ended"
  | "transaction_placeholder";

export interface BaseRecord {
  id: EntityId;
  createdAt: string;
  updatedAt: string;
}

export interface Organization extends BaseRecord {
  name: string;
  slug: string;
  legalName: string;
  timezone: string;
  currencyCode: string;
}

export interface Location extends BaseRecord {
  organizationId: EntityId;
  name: string;
  code: string;
  address1: string;
  city: string;
  region: string;
  postalCode: string;
  isActive: boolean;
}

export interface RoleDefinition {
  key: RoleKey;
  label: string;
  description: string;
  permissions: PermissionKey[];
}

export interface Employee extends BaseRecord {
  organizationId: EntityId;
  locationIds: EntityId[];
  roleKey: RoleKey;
  firstName: string;
  lastName: string;
  displayName: string;
  email?: string;
  pinHint: string;
  isActive: boolean;
}

export interface Category extends BaseRecord {
  organizationId: EntityId;
  name: string;
  slug: string;
  parentCategoryId?: EntityId;
  sortOrder: number;
  imageUrl?: string;
}

export interface ModifierGroup extends BaseRecord {
  organizationId: EntityId;
  name: string;
  selectionMode: "single" | "multiple";
  minSelections: number;
  maxSelections: number;
}

export interface Modifier extends BaseRecord {
  organizationId: EntityId;
  modifierGroupId: EntityId;
  name: string;
  priceDelta: number;
  sortOrder: number;
}

export interface Product extends BaseRecord {
  organizationId: EntityId;
  categoryId: EntityId;
  name: string;
  slug: string;
  description?: string;
  imageUrl?: string;
  isActive: boolean;
  isTouchFavorite: boolean;
  defaultVariantId?: EntityId;
  modifierGroupIds: EntityId[];
}

export interface ProductVariant extends BaseRecord {
  organizationId: EntityId;
  productId: EntityId;
  sku: string;
  barcode?: string;
  name: string;
  sizeLabel?: string;
  colorLabel?: string;
  price: number;
  compareAtPrice?: number;
  cost?: number;
  isActive: boolean;
}

export interface InventoryLevel extends BaseRecord {
  organizationId: EntityId;
  locationId: EntityId;
  productVariantId: EntityId;
  onHand: number;
  reserved: number;
  reorderPoint: number;
}

export interface ApprovalThresholds {
  discountOver: number;
  itemVoidOver: number;
  transactionVoidOver: number;
  storeCreditIssuanceOver: number;
  manualPriceOverrideOver: number;
  returnWithoutManagerOver: number;
}

export interface RegisterConfiguration {
  locationId: EntityId;
  noReceiptEnabled: boolean;
  receiptMode: "browser-print" | "none";
  supportedTenders: TenderType[];
  approvalThresholds: ApprovalThresholds;
}

export interface ShiftRecord {
  id: EntityId;
  locationId: EntityId;
  employeeId: EntityId;
  registerSessionId: EntityId;
  status: "open" | "closed";
  openedAt: string;
  openingFloat: number;
  openedNote?: string;
  closedAt?: string;
  closingExpectedCash?: number;
  closingDeclaredCash?: number;
  closingVariance?: number;
  closedNote?: string;
}

export interface RegisterSessionRecord {
  id: EntityId;
  authSessionId: EntityId;
  employeeId: EntityId;
  locationId: EntityId;
  status: "active" | "ended";
  startedAt: string;
  endedAt?: string;
  activeShiftId?: EntityId;
  lastCartId?: EntityId;
  lastTransactionId?: EntityId;
  pendingExceptionIds: EntityId[];
}

export interface TransactionTenderPlaceholder {
  id: EntityId;
  transactionId: EntityId;
  tenderType: TenderType;
  amount: number;
  metadata?: Record<string, string>;
}

export interface TransactionEventPlaceholder {
  id: EntityId;
  transactionId: EntityId;
  eventKind: AuditEventKind;
  actorEmployeeId: EntityId;
  notes?: string;
  payload?: Record<string, string>;
  createdAt: string;
}

export interface TransactionExceptionPlaceholder {
  id: EntityId;
  transactionId: EntityId;
  exceptionCode:
    | "discount_threshold"
    | "item_void_threshold"
    | "transaction_void_threshold"
    | "store_credit_threshold"
    | "manual_price_override_threshold"
    | "return_threshold";
  requiresManagerApproval: boolean;
  resolvedAt?: string;
}
