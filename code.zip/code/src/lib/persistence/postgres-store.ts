import 'server-only';
import pool from '@/lib/db';
import type { Category, Employee, InventoryLevel, Product, ProductVariant, RegisterSessionRecord, ShiftRecord } from '@/lib/domain/types';
import type { AuthCredentialRecord, InventoryAdjustmentRecord } from '@/lib/persistence/types';

// ── Helpers ───────────────────────────────────────────────────────────

function toCategory(row: Record<string, unknown>): Category {
  return {
    id: row.id as string,
    organizationId: row.organization_id as string,
    name: row.name as string,
    slug: row.slug as string,
    parentCategoryId: (row.parent_category_id as string) ?? undefined,
    sortOrder: row.sort_order as number,
    imageUrl: (row.image_url as string) ?? undefined,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

function toProduct(row: Record<string, unknown>): Product {
  return {
    id: row.id as string,
    organizationId: row.organization_id as string,
    categoryId: row.category_id as string,
    name: row.name as string,
    slug: row.slug as string,
    description: (row.description as string) ?? undefined,
    imageUrl: (row.image_url as string) ?? undefined,
    isActive: row.is_active as boolean,
    isTouchFavorite: row.is_touch_favorite as boolean,
    defaultVariantId: (row.default_variant_id as string) ?? undefined,
    modifierGroupIds: (row.modifier_group_ids as string[]) ?? [],
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

function toVariant(row: Record<string, unknown>): ProductVariant {
  return {
    id: row.id as string,
    organizationId: row.organization_id as string,
    productId: row.product_id as string,
    sku: row.sku as string,
    barcode: (row.barcode as string) ?? undefined,
    name: row.name as string,
    sizeLabel: (row.size_label as string) ?? undefined,
    colorLabel: (row.color_label as string) ?? undefined,
    price: Number(row.price),
    compareAtPrice: row.compare_at_price != null ? Number(row.compare_at_price) : undefined,
    cost: row.cost != null ? Number(row.cost) : undefined,
    isActive: row.is_active as boolean,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

function toInventory(row: Record<string, unknown>): InventoryLevel {
  return {
    id: row.id as string,
    organizationId: row.organization_id as string,
    locationId: row.location_id as string,
    productVariantId: row.product_variant_id as string,
    onHand: row.on_hand as number,
    reserved: row.reserved as number,
    reorderPoint: row.reorder_point as number,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

function toEmployee(row: Record<string, unknown>): Employee {
  return {
    id: row.id as string,
    organizationId: row.organization_id as string,
    locationIds: (row.location_ids as string[]) ?? [],
    roleKey: row.role_key as Employee['roleKey'],
    firstName: row.first_name as string,
    lastName: row.last_name as string,
    displayName: row.display_name as string,
    email: (row.email as string) ?? undefined,
    pinHint: (row.pin_hint as string) ?? '',
    isActive: row.is_active as boolean,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

// ── Categories ────────────────────────────────────────────────────────

export async function pgReadCategories(): Promise<Category[]> {
  const { rows } = await pool.query('SELECT * FROM categories ORDER BY sort_order');
  return rows.map(toCategory);
}

export async function pgCreateCategory(data: {
  id: string; organizationId: string; name: string; slug: string;
  sortOrder: number; imageUrl?: string; parentCategoryId?: string;
}): Promise<Category> {
  const ts = new Date().toISOString();
  const { rows } = await pool.query(
    `INSERT INTO categories (id, organization_id, slug, name, sort_order, image_url, parent_category_id, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $8) RETURNING *`,
    [data.id, data.organizationId, data.slug, data.name, data.sortOrder, data.imageUrl ?? null, data.parentCategoryId ?? null, ts],
  );
  return toCategory(rows[0]);
}

export async function pgUpdateCategory(id: string, data: Partial<{ name: string; slug: string; sortOrder: number; imageUrl: string | null }>): Promise<Category | null> {
  const sets: string[] = [];
  const vals: unknown[] = [];
  let i = 1;
  if (data.name !== undefined) { sets.push(`name = $${i++}`); vals.push(data.name); }
  if (data.slug !== undefined) { sets.push(`slug = $${i++}`); vals.push(data.slug); }
  if (data.sortOrder !== undefined) { sets.push(`sort_order = $${i++}`); vals.push(data.sortOrder); }
  if (data.imageUrl !== undefined) { sets.push(`image_url = $${i++}`); vals.push(data.imageUrl); }
  if (sets.length === 0) return null;
  sets.push(`updated_at = $${i++}`);
  vals.push(new Date().toISOString());
  vals.push(id);
  const { rows } = await pool.query(`UPDATE categories SET ${sets.join(', ')} WHERE id = $${i} RETURNING *`, vals);
  return rows[0] ? toCategory(rows[0]) : null;
}

export async function pgDeleteCategory(id: string): Promise<boolean> {
  const { rowCount } = await pool.query('DELETE FROM categories WHERE id = $1', [id]);
  return (rowCount ?? 0) > 0;
}

// ── Products ──────────────────────────────────────────────────────────

export async function pgReadProducts(): Promise<Product[]> {
  const { rows } = await pool.query(
    `SELECT p.*, COALESCE(array_agg(pmg.modifier_group_id) FILTER (WHERE pmg.modifier_group_id IS NOT NULL), '{}') AS modifier_group_ids
     FROM products p LEFT JOIN product_modifier_groups pmg ON p.id = pmg.product_id
     GROUP BY p.id ORDER BY p.name`,
  );
  return rows.map(toProduct);
}

export async function pgCreateProduct(data: {
  id: string; organizationId: string; categoryId: string; name: string; slug: string;
  description?: string; imageUrl?: string; isActive: boolean; isTouchFavorite: boolean;
  defaultVariantId?: string; modifierGroupIds: string[];
}): Promise<Product> {
  const ts = new Date().toISOString();
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      `INSERT INTO products (id, organization_id, category_id, slug, name, description, image_url, is_active, is_touch_favorite, default_variant_id, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $11) RETURNING *`,
      [data.id, data.organizationId, data.categoryId, data.slug, data.name, data.description ?? null, data.imageUrl ?? null, data.isActive, data.isTouchFavorite, data.defaultVariantId ?? null, ts],
    );
    for (const mgId of data.modifierGroupIds) {
      await client.query('INSERT INTO product_modifier_groups (product_id, modifier_group_id) VALUES ($1, $2)', [data.id, mgId]);
    }
    await client.query('COMMIT');
    return { ...toProduct(rows[0]), modifierGroupIds: data.modifierGroupIds };
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

export async function pgUpdateProduct(id: string, data: Partial<{
  name: string; slug: string; categoryId: string; description: string | null;
  imageUrl: string | null; isActive: boolean; isTouchFavorite: boolean; defaultVariantId: string | null;
}>): Promise<Product | null> {
  const sets: string[] = [];
  const vals: unknown[] = [];
  let i = 1;
  if (data.name !== undefined) { sets.push(`name = $${i++}`); vals.push(data.name); }
  if (data.slug !== undefined) { sets.push(`slug = $${i++}`); vals.push(data.slug); }
  if (data.categoryId !== undefined) { sets.push(`category_id = $${i++}`); vals.push(data.categoryId); }
  if (data.description !== undefined) { sets.push(`description = $${i++}`); vals.push(data.description); }
  if (data.imageUrl !== undefined) { sets.push(`image_url = $${i++}`); vals.push(data.imageUrl); }
  if (data.isActive !== undefined) { sets.push(`is_active = $${i++}`); vals.push(data.isActive); }
  if (data.isTouchFavorite !== undefined) { sets.push(`is_touch_favorite = $${i++}`); vals.push(data.isTouchFavorite); }
  if (data.defaultVariantId !== undefined) { sets.push(`default_variant_id = $${i++}`); vals.push(data.defaultVariantId); }
  if (sets.length === 0) return null;
  sets.push(`updated_at = $${i++}`);
  vals.push(new Date().toISOString());
  vals.push(id);
  const { rows } = await pool.query(`UPDATE products SET ${sets.join(', ')} WHERE id = $${i} RETURNING *`, vals);
  if (!rows[0]) return null;
  const mgRows = await pool.query('SELECT modifier_group_id FROM product_modifier_groups WHERE product_id = $1', [id]);
  return { ...toProduct(rows[0]), modifierGroupIds: mgRows.rows.map((r: Record<string, unknown>) => r.modifier_group_id as string) };
}

export async function pgDeleteProduct(id: string): Promise<boolean> {
  const { rowCount } = await pool.query('DELETE FROM products WHERE id = $1', [id]);
  return (rowCount ?? 0) > 0;
}

// ── Variants ──────────────────────────────────────────────────────────

export async function pgReadVariants(): Promise<ProductVariant[]> {
  const { rows } = await pool.query('SELECT * FROM product_variants ORDER BY name');
  return rows.map(toVariant);
}

export async function pgCreateVariant(data: {
  id: string; organizationId: string; productId: string; sku: string; barcode?: string;
  name: string; sizeLabel?: string; colorLabel?: string; price: number; cost?: number;
  compareAtPrice?: number; isActive: boolean;
}): Promise<ProductVariant> {
  const ts = new Date().toISOString();
  const { rows } = await pool.query(
    `INSERT INTO product_variants (id, organization_id, product_id, sku, barcode, name, size_label, color_label, price, compare_at_price, cost, is_active, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $13) RETURNING *`,
    [data.id, data.organizationId, data.productId, data.sku, data.barcode ?? null, data.name, data.sizeLabel ?? null, data.colorLabel ?? null, data.price, data.compareAtPrice ?? null, data.cost ?? null, data.isActive, ts],
  );
  return toVariant(rows[0]);
}

export async function pgUpdateVariant(id: string, data: Partial<{
  name: string; sku: string; barcode: string | null; sizeLabel: string | null;
  colorLabel: string | null; price: number; compareAtPrice: number | null;
  cost: number | null; isActive: boolean;
}>): Promise<ProductVariant | null> {
  const sets: string[] = [];
  const vals: unknown[] = [];
  let i = 1;
  if (data.name !== undefined) { sets.push(`name = $${i++}`); vals.push(data.name); }
  if (data.sku !== undefined) { sets.push(`sku = $${i++}`); vals.push(data.sku); }
  if (data.barcode !== undefined) { sets.push(`barcode = $${i++}`); vals.push(data.barcode); }
  if (data.sizeLabel !== undefined) { sets.push(`size_label = $${i++}`); vals.push(data.sizeLabel); }
  if (data.colorLabel !== undefined) { sets.push(`color_label = $${i++}`); vals.push(data.colorLabel); }
  if (data.price !== undefined) { sets.push(`price = $${i++}`); vals.push(data.price); }
  if (data.compareAtPrice !== undefined) { sets.push(`compare_at_price = $${i++}`); vals.push(data.compareAtPrice); }
  if (data.cost !== undefined) { sets.push(`cost = $${i++}`); vals.push(data.cost); }
  if (data.isActive !== undefined) { sets.push(`is_active = $${i++}`); vals.push(data.isActive); }
  if (sets.length === 0) return null;
  sets.push(`updated_at = $${i++}`);
  vals.push(new Date().toISOString());
  vals.push(id);
  const { rows } = await pool.query(`UPDATE product_variants SET ${sets.join(', ')} WHERE id = $${i} RETURNING *`, vals);
  return rows[0] ? toVariant(rows[0]) : null;
}

export async function pgDeleteVariant(id: string): Promise<boolean> {
  const { rowCount } = await pool.query('DELETE FROM product_variants WHERE id = $1', [id]);
  return (rowCount ?? 0) > 0;
}

// ── Inventory ─────────────────────────────────────────────────────────

export async function pgReadInventory(): Promise<InventoryLevel[]> {
  const { rows } = await pool.query('SELECT * FROM inventory_levels');
  return rows.map(toInventory);
}

export async function pgCreateInventoryLevel(data: {
  id: string; organizationId: string; locationId: string; productVariantId: string;
  onHand: number; reserved: number; reorderPoint: number;
}): Promise<InventoryLevel> {
  const ts = new Date().toISOString();
  const { rows } = await pool.query(
    `INSERT INTO inventory_levels (id, organization_id, location_id, product_variant_id, on_hand, reserved, reorder_point, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $8) RETURNING *`,
    [data.id, data.organizationId, data.locationId, data.productVariantId, data.onHand, data.reserved, data.reorderPoint, ts],
  );
  return toInventory(rows[0]);
}

export async function pgAdjustInventory(inventoryLevelId: string, delta: number, employeeId: string, reason: string): Promise<{ level: InventoryLevel; adjustment: InventoryAdjustmentRecord }> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const ts = new Date().toISOString();
    const { rows: invRows } = await client.query(
      `UPDATE inventory_levels SET on_hand = GREATEST(0, on_hand + $1), updated_at = $2 WHERE id = $3 RETURNING *`,
      [delta, ts, inventoryLevelId],
    );
    if (!invRows[0]) throw new Error('Inventory row not found');
    const level = toInventory(invRows[0]);

    const adjId = crypto.randomUUID();
    await client.query(
      `INSERT INTO inventory_adjustments (id, organization_id, location_id, product_variant_id, employee_id, quantity_delta, reason_code, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [adjId, level.organizationId, level.locationId, level.productVariantId, employeeId, delta, reason, ts],
    );

    await client.query('COMMIT');
    const adjustment: InventoryAdjustmentRecord = {
      id: adjId, inventoryLevelId, productVariantId: level.productVariantId,
      locationId: level.locationId, employeeId, reason, delta, resultingOnHand: level.onHand, createdAt: ts,
    };
    return { level, adjustment };
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

// ── Employees ─────────────────────────────────────────────────────────

export async function pgReadEmployees(): Promise<Employee[]> {
  const { rows } = await pool.query(
    `SELECT ep.*, COALESCE(array_agg(el.location_id) FILTER (WHERE el.location_id IS NOT NULL), '{}') AS location_ids
     FROM employee_profiles ep LEFT JOIN employee_locations el ON ep.id = el.employee_id
     GROUP BY ep.id ORDER BY ep.last_name`,
  );
  return rows.map(toEmployee);
}

export async function pgCreateEmployee(data: {
  id: string; organizationId: string; roleKey: string; firstName: string; lastName: string;
  displayName: string; email?: string; pinHash: string; passwordHash?: string; pinHint: string;
  isActive: boolean; locationIds: string[];
}): Promise<Employee> {
  const client = await pool.connect();
  const ts = new Date().toISOString();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      `INSERT INTO employee_profiles (id, organization_id, role_key, first_name, last_name, display_name, email, pin_hash, password_hash, pin_hint, pin_last_rotated_at, is_active, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $13) RETURNING *`,
      [data.id, data.organizationId, data.roleKey, data.firstName, data.lastName, data.displayName, data.email ?? null, data.pinHash, data.passwordHash ?? null, data.pinHint, ts, data.isActive, ts],
    );
    for (const locId of data.locationIds) {
      await client.query('INSERT INTO employee_locations (employee_id, location_id) VALUES ($1, $2)', [data.id, locId]);
    }
    await client.query('COMMIT');
    return { ...toEmployee(rows[0]), locationIds: data.locationIds };
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

export async function pgToggleEmployee(id: string): Promise<boolean> {
  const { rowCount } = await pool.query(
    `UPDATE employee_profiles SET is_active = NOT is_active, updated_at = $1 WHERE id = $2`,
    [new Date().toISOString(), id],
  );
  return (rowCount ?? 0) > 0;
}

export async function pgReadEmployeeById(id: string): Promise<Employee | null> {
  const { rows } = await pool.query(
    `SELECT ep.*, COALESCE(array_agg(el.location_id) FILTER (WHERE el.location_id IS NOT NULL), '{}') AS location_ids
     FROM employee_profiles ep LEFT JOIN employee_locations el ON ep.id = el.employee_id
     WHERE ep.id = $1 GROUP BY ep.id`,
    [id],
  );
  return rows[0] ? toEmployee(rows[0]) : null;
}

// ── Auth credential helpers ───────────────────────────────────────────

export async function pgFindCredentialByEmail(email: string): Promise<(AuthCredentialRecord & { passwordHash?: string }) | null> {
  const { rows } = await pool.query(
    `SELECT id AS employee_id, email, password_hash, pin_hash, pin_last_rotated_at FROM employee_profiles WHERE LOWER(email) = LOWER($1) AND is_active = true`,
    [email],
  );
  if (!rows[0]) return null;
  const r = rows[0] as Record<string, unknown>;
  return {
    employeeId: r.employee_id as string,
    email: (r.email as string) ?? undefined,
    passwordHash: (r.password_hash as string) ?? undefined,
    pinHash: (r.pin_hash as string) ?? undefined,
    pinLastRotatedAt: r.pin_last_rotated_at ? String(r.pin_last_rotated_at) : undefined,
  };
}

export async function pgFindCredentialByPin(pinVerifier: (hash: string) => boolean): Promise<AuthCredentialRecord | null> {
  const { rows } = await pool.query('SELECT id AS employee_id, email, pin_hash, pin_last_rotated_at FROM employee_profiles WHERE is_active = true');
  for (const r of rows) {
    const row = r as Record<string, unknown>;
    if (row.pin_hash && pinVerifier(row.pin_hash as string)) {
      return {
        employeeId: row.employee_id as string,
        email: (row.email as string) ?? undefined,
        pinHash: (row.pin_hash as string) ?? undefined,
        pinLastRotatedAt: row.pin_last_rotated_at ? String(row.pin_last_rotated_at) : undefined,
      };
    }
  }
  return null;
}

// ── Audit events ──────────────────────────────────────────────────────

export async function pgInsertAuditEvent(
  orgId: string, locationId: string | null, employeeId: string | null,
  entityType: string, entityId: string | null, eventKind: string, payload: Record<string, unknown> = {},
) {
  await pool.query(
    `INSERT INTO audit_events (organization_id, location_id, employee_id, entity_type, entity_id, event_kind, payload)
     VALUES ($1, $2, $3, $4, $5, $6, $7)`,
    [orgId, locationId, employeeId, entityType, entityId, eventKind, JSON.stringify(payload)],
  );
}

// ── Organization ──────────────────────────────────────────────────────

export async function pgReadOrganization() {
  const { rows } = await pool.query('SELECT * FROM organizations LIMIT 1');
  if (!rows[0]) return null;
  const r = rows[0] as Record<string, unknown>;
  return {
    id: r.id as string, name: r.name as string, slug: r.slug as string,
    legalName: r.legal_name as string, timezone: r.timezone as string,
    currencyCode: r.currency_code as string,
    createdAt: String(r.created_at), updatedAt: String(r.updated_at),
  };
}

export async function pgReadLocations() {
  const { rows } = await pool.query('SELECT * FROM locations WHERE is_active = true ORDER BY name');
  return rows.map((r: Record<string, unknown>) => ({
    id: r.id as string, organizationId: r.organization_id as string,
    name: r.name as string, code: r.code as string,
    address1: r.address_1 as string, city: r.city as string,
    region: r.region as string, postalCode: r.postal_code as string,
    isActive: r.is_active as boolean,
    createdAt: String(r.created_at), updatedAt: String(r.updated_at),
  }));
}

// ── Register Sessions ─────────────────────────────────────────────────

function toRegisterSession(r: Record<string, unknown>): RegisterSessionRecord {
  return {
    id: r.id as string,
    authSessionId: r.auth_session_id as string,
    employeeId: r.employee_id as string,
    locationId: r.location_id as string,
    status: r.status as 'active' | 'ended',
    startedAt: String(r.started_at),
    endedAt: r.ended_at ? String(r.ended_at) : undefined,
    activeShiftId: (r.active_shift_id as string) ?? undefined,
    lastCartId: (r.last_cart_id as string) ?? undefined,
    lastTransactionId: (r.last_transaction_id as string) ?? undefined,
    pendingExceptionIds: (r.pending_exception_ids as string[]) ?? [],
  };
}

function toShift(r: Record<string, unknown>): ShiftRecord {
  return {
    id: r.id as string,
    locationId: r.location_id as string,
    employeeId: r.employee_id as string,
    registerSessionId: r.register_session_id as string,
    status: r.status as 'open' | 'closed',
    openedAt: String(r.opened_at),
    openingFloat: Number(r.opening_float),
    openedNote: (r.opened_note as string) ?? undefined,
    closedAt: r.closed_at ? String(r.closed_at) : undefined,
    closingExpectedCash: r.closing_expected_cash != null ? Number(r.closing_expected_cash) : undefined,
    closingDeclaredCash: r.closing_declared_cash != null ? Number(r.closing_declared_cash) : undefined,
    closingVariance: r.closing_variance != null ? Number(r.closing_variance) : undefined,
    closedNote: (r.closed_note as string) ?? undefined,
  };
}

export async function pgCreateRegisterSession(data: {
  id: string; authSessionId: string; employeeId: string; locationId: string;
}): Promise<RegisterSessionRecord> {
  const ts = new Date().toISOString();
  const { rows } = await pool.query(
    `INSERT INTO register_sessions (id, auth_session_id, employee_id, location_id, status, started_at, pending_exception_ids)
     VALUES ($1, $2, $3, $4, 'active', $5, '[]'::jsonb) RETURNING *`,
    [data.id, data.authSessionId, data.employeeId, data.locationId, ts],
  );
  return toRegisterSession(rows[0]);
}

export async function pgFindActiveRegisterSession(authSessionId: string): Promise<RegisterSessionRecord | null> {
  const { rows } = await pool.query(
    `SELECT * FROM register_sessions WHERE auth_session_id = $1 AND status = 'active' LIMIT 1`,
    [authSessionId],
  );
  return rows[0] ? toRegisterSession(rows[0]) : null;
}

export async function pgEndRegisterSession(id: string): Promise<void> {
  const ts = new Date().toISOString();
  await pool.query(
    `UPDATE register_sessions SET status = 'ended', ended_at = $1, active_shift_id = NULL WHERE id = $2`,
    [ts, id],
  );
}

export async function pgOpenShift(data: {
  id: string; locationId: string; employeeId: string; registerSessionId: string;
  openingFloat: number; openedNote?: string;
}): Promise<ShiftRecord> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const ts = new Date().toISOString();
    const { rows } = await client.query(
      `INSERT INTO shifts (id, location_id, employee_id, register_session_id, status, opened_at, opening_float, opened_note)
       VALUES ($1, $2, $3, $4, 'open', $5, $6, $7) RETURNING *`,
      [data.id, data.locationId, data.employeeId, data.registerSessionId, ts, data.openingFloat, data.openedNote ?? null],
    );
    await client.query(
      `UPDATE register_sessions SET active_shift_id = $1 WHERE id = $2`,
      [data.id, data.registerSessionId],
    );
    await client.query('COMMIT');
    return toShift(rows[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

export async function pgCloseShift(shiftId: string, registerSessionId: string, data: {
  closingExpectedCash: number; closingDeclaredCash: number; closedNote?: string;
}): Promise<ShiftRecord> {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const ts = new Date().toISOString();
    const variance = Number((data.closingDeclaredCash - data.closingExpectedCash).toFixed(2));
    const { rows } = await client.query(
      `UPDATE shifts SET status = 'closed', closed_at = $1, closing_expected_cash = $2,
       closing_declared_cash = $3, closing_variance = $4, closed_note = $5
       WHERE id = $6 AND status = 'open' RETURNING *`,
      [ts, data.closingExpectedCash, data.closingDeclaredCash, variance, data.closedNote ?? null, shiftId],
    );
    if (!rows[0]) throw new Error('Shift not found or already closed');
    await client.query(
      `UPDATE register_sessions SET active_shift_id = NULL WHERE id = $1`,
      [registerSessionId],
    );
    await client.query('COMMIT');
    return toShift(rows[0]);
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

export async function pgFindOpenShift(shiftId: string): Promise<ShiftRecord | null> {
  const { rows } = await pool.query(
    `SELECT * FROM shifts WHERE id = $1 AND status = 'open' LIMIT 1`,
    [shiftId],
  );
  return rows[0] ? toShift(rows[0]) : null;
}

export async function pgAutoCloseShift(shiftId: string): Promise<void> {
  const ts = new Date().toISOString();
  await pool.query(
    `UPDATE shifts SET status = 'closed', closed_at = $1,
     closing_expected_cash = opening_float, closing_declared_cash = opening_float,
     closing_variance = 0, closed_note = 'Auto-closed because register session ended without manual shift close.'
     WHERE id = $2 AND status = 'open'`,
    [ts, shiftId],
  );
}

export async function pgGetCashDrawerBalance(registerSessionId: string): Promise<number> {
  const { rows } = await pool.query(
    `SELECT opening_float FROM shifts WHERE register_session_id = $1 AND status = 'open' LIMIT 1`,
    [registerSessionId],
  );
  return rows[0] ? Number(rows[0].opening_float) : 0;
}
