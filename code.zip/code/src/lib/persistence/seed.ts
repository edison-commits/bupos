import { hashSecret } from "@/lib/auth/crypto";
import { seedBundle } from "@/lib/data/mock-data";
import type { LocalStoreData } from "@/lib/persistence/types";

const now = new Date().toISOString();

export function createSeedStore(): LocalStoreData {
  return {
    ...seedBundle,
    inventoryAdjustments: [],
    shifts: [],
    registerSessions: [],
    authCredentials: [
      {
        employeeId: seedBundle.employees[0].id,
        email: "owner@swiftpos.local",
        passwordHash: hashSecret("ownerpass"),
        pinHash: hashSecret("1111"),
        passwordLastRotatedAt: now,
        pinLastRotatedAt: now,
      },
      {
        employeeId: seedBundle.employees[1].id,
        email: "manager@swiftpos.local",
        passwordHash: hashSecret("managerpass"),
        pinHash: hashSecret("2222"),
        passwordLastRotatedAt: now,
        pinLastRotatedAt: now,
      },
      {
        employeeId: seedBundle.employees[2].id,
        pinHash: hashSecret("3333"),
        pinLastRotatedAt: now,
      },
    ],
    sessions: [],
  };
}
