import "server-only";

import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { createSeedStore } from "@/lib/persistence/seed";
import type { LocalStoreData } from "@/lib/persistence/types";

const DATA_DIR = path.join(process.cwd(), ".data");
const STORE_PATH = path.join(DATA_DIR, "swiftpos-store.json");

async function ensureStoreFile() {
  await mkdir(DATA_DIR, { recursive: true });

  try {
    await readFile(STORE_PATH, "utf8");
  } catch {
    const seed = createSeedStore();
    await writeFile(STORE_PATH, JSON.stringify(seed, null, 2), "utf8");
  }
}

function normalizeStore(store: LocalStoreData): LocalStoreData {
  return {
    ...store,
    inventoryAdjustments: store.inventoryAdjustments ?? [],
    shifts: store.shifts ?? [],
    registerSessions: store.registerSessions ?? [],
    transactionTenderPlaceholders: store.transactionTenderPlaceholders ?? [],
    transactionEventPlaceholders: store.transactionEventPlaceholders ?? [],
    transactionExceptionPlaceholders: store.transactionExceptionPlaceholders ?? [],
    authCredentials: store.authCredentials ?? [],
    sessions: store.sessions ?? [],
  };
}

export async function readStore(): Promise<LocalStoreData> {
  await ensureStoreFile();
  const raw = await readFile(STORE_PATH, "utf8");
  return normalizeStore(JSON.parse(raw) as LocalStoreData);
}

export async function writeStore(store: LocalStoreData) {
  await ensureStoreFile();
  await writeFile(STORE_PATH, JSON.stringify(normalizeStore(store), null, 2), "utf8");
}

export async function mutateStore<T>(updater: (store: LocalStoreData) => Promise<T> | T): Promise<T> {
  const store = await readStore();
  const result = await updater(store);
  await writeStore(store);
  return result;
}

export function getStorePath() {
  return STORE_PATH;
}
