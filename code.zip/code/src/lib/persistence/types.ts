import type {
  Category,
  Employee,
  InventoryLevel,
  Location,
  Modifier,
  ModifierGroup,
  Organization,
  Product,
  ProductVariant,
  RegisterConfiguration,
  RegisterSessionRecord,
  RoleDefinition,
  ShiftRecord,
  TransactionEventPlaceholder,
  TransactionExceptionPlaceholder,
  TransactionTenderPlaceholder,
} from "@/lib/domain/types";

export interface InventoryAdjustmentRecord {
  id: string;
  inventoryLevelId: string;
  productVariantId: string;
  locationId: string;
  employeeId: string;
  reason: string;
  delta: number;
  resultingOnHand: number;
  createdAt: string;
}

export interface AuthCredentialRecord {
  employeeId: string;
  email?: string;
  passwordHash?: string;
  pinHash?: string;
  passwordLastRotatedAt?: string;
  pinLastRotatedAt?: string;
}

export interface SessionRecord {
  id: string;
  employeeId: string;
  scope: "admin" | "register";
  locationId?: string;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: string;
}

export interface LocalStoreData {
  organization: Organization;
  locations: Location[];
  employees: Employee[];
  roles: RoleDefinition[];
  categories: Category[];
  modifierGroups: ModifierGroup[];
  modifiers: Modifier[];
  products: Product[];
  variants: ProductVariant[];
  inventory: InventoryLevel[];
  inventoryAdjustments: InventoryAdjustmentRecord[];
  registerConfiguration: RegisterConfiguration;
  shifts: ShiftRecord[];
  registerSessions: RegisterSessionRecord[];
  transactionTenderPlaceholders: TransactionTenderPlaceholder[];
  transactionEventPlaceholders: TransactionEventPlaceholder[];
  transactionExceptionPlaceholders: TransactionExceptionPlaceholder[];
  authCredentials: AuthCredentialRecord[];
  sessions: SessionRecord[];
}

export interface AdminSessionContext {
  session: SessionRecord;
  employee: Employee;
}

export interface RegisterSessionContext {
  session: SessionRecord;
  employee: Employee;
  location: Location;
  registerSession: RegisterSessionRecord;
  activeShift: ShiftRecord | null;
}
